import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/audio_record/presentation/audio_recorder_page.dart';
import 'package:legalfactfinder2025/features/authentication/auth_controller.dart';
import 'package:legalfactfinder2025/features/friend/presentation/friend_request_page.dart';
import 'package:legalfactfinder2025/features/notification/presentation/notification_screen.dart';
import 'package:legalfactfinder2025/features/work_room/presentation/work_room_list_screen.dart';
import 'package:legalfactfinder2025/features/friend/presentation/friend_list_screen.dart';
import 'package:legalfactfinder2025/features/work_room/presentation/add_work_room_page.dart';
import 'package:legalfactfinder2025/core/setting/setting_screen.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  _MainLayoutState createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  late AuthController authController;

  @override
  void initState() {
    super.initState();

    // Initialize the AuthController
    authController = Get.find<AuthController>();

    // Fetch userId and check authentication status
    print("Checking authentication status...");
    authController.refreshUser(); // Refresh user info
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).viewPadding.bottom;
    final isRoundedDevice = Platform.isIOS && bottomPadding > 20;
    return Scaffold(
      body: Obx(() {
        // Check if userId is null, and show loading until it's fetched
        if (authController.userId.value == null) {
          print("User is not logged in yet. Displaying loading screen...");
          return const Center(child: CircularProgressIndicator());
        }

        print("MainLayout: User is logged in!");

        final List<Widget> screens = [
          WorkRoomListScreen(myUserId: authController.userId.value!), // Pass the logged-in user ID
          FriendListScreen(),
          const Center(child: Text('Call History Page')),
          SettingScreen(),
        ];

        return DefaultTabController(
          length: screens.length,
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.white,
              automaticallyImplyLeading: false,
              title: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        print("Search tapped");
                      },
                      child: Container(
                        height: 36,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        alignment: Alignment.centerLeft,
                        child: Row(
                          children: const [
                            Icon(Icons.search),
                            SizedBox(width: 8),
                            Text('Search...', style: TextStyle(fontSize: 14)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  GestureDetector(
                    onTap: () => _showBottomSheet(context),
                    child: const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Icon(Icons.add_box),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      print("Navigating to Notifications page...");
                      Get.to(() => NotificationPage());
                    },
                    child: const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Icon(Icons.notifications),
                    ),
                  ),
                ],
              ),
            ),
            body: TabBarView(

              physics: const NeverScrollableScrollPhysics(),
              children: screens,
            ),
            bottomNavigationBar: Padding(
              padding: EdgeInsets.only(bottom: isRoundedDevice  ? 10 : 0),
              child: const TabBar(
                tabs: [
                  Tab(icon: Icon(Icons.meeting_room)),
                  Tab(icon: Icon(Icons.group)),
                  Tab(icon: Icon(Icons.history)),
                  Tab(icon: Icon(Icons.settings)),
                ],
                labelColor: Colors.lightBlue,
                unselectedLabelColor: Colors.grey,
                indicatorColor: Colors.transparent,
              ),
            ),
          ),
        );
      }),
    );
  }

  // Function to show the bottom sheet for various actions
  void _showBottomSheet(BuildContext context) {
    print("Opening bottom sheet...");
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.person_add),
              title: const Text('친구 초대'),
              onTap: () {
                Navigator.pop(context);
                print("친구 초대 선택");
                Get.to(() => FriendRequestPage());

              },
            ),
            ListTile(
              leading: const Icon(Icons.note_add),
              title: const Text('회의록 생성'),
              onTap: () {
                Navigator.pop(context);
                print("Navigating to Audio Recorder page...");
                Get.to(() => AudioRecorderPage());
              },
            ),
            ListTile(
              leading: const Icon(Icons.meeting_room),
              title: const Text('Work Room 생성'),
              onTap: () {
                Navigator.pop(context);
                print("Navigating to Add Work Room page...");
                Get.to(() => const AddWorkRoomPage());
              },
            ),
          ],
        );
      },
    );
  }
}
