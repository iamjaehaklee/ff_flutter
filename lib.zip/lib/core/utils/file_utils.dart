/// 주어진 전체 경로 문자열에서 파일명을 제외한 디렉토리 경로만 반환합니다.
/// 예: "folder/subfolder/file.txt" -> "folder/subfolder"
String extractDirectoryPath(String fullPath) {
  // '/'와 '\' 둘 다 지원하여 마지막 경로 구분자를 찾습니다.
  final lastSlashIndex = fullPath.lastIndexOf('/');
  final lastBackslashIndex = fullPath.lastIndexOf('\\');
  final lastSeparatorIndex = lastSlashIndex > lastBackslashIndex ? lastSlashIndex : lastBackslashIndex;

  if (lastSeparatorIndex == -1) {
    // 경로 구분자가 없으면, 디렉토리 경로가 없다고 판단합니다.
    return '';
  }

  // 디렉토리 경로를 반환 (파일명 제외)
  return fullPath.substring(0, lastSeparatorIndex);
}
