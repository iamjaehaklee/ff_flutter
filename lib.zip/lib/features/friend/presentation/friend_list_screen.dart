import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/friend/friend_list_controller.dart';
import 'package:legalfactfinder2025/features/friend/presentation/friend_request_page.dart';
import 'package:legalfactfinder2025/features/profile/presentation/profile_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FriendListScreen extends StatelessWidget {
  final FriendListController controller = Get.put(FriendListController());

  FriendListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ✅ 현재 로그인된 사용자 ID 가져오기
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      return const Center(child: Text("Please log in to see your friends."));
    }

    controller.fetchFriends(userId); // ✅ 친구 목록 불러오기

    return Scaffold(
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }
        if (controller.errorMessage.isNotEmpty) {
          return Center(child: Text(controller.errorMessage.value));
        }
        if (controller.friends.isEmpty) {
          return _buildEmptyState(); // ✅ 친구가 없을 때의 UI 추가
        }
        return Column(
          children: [
            Expanded(
              child: ListView.separated(
                itemCount: controller.friends.length,
                separatorBuilder: (context, index) => const Divider(
                  thickness: 1,
                  height: 1,
                ),
                itemBuilder: (context, index) {
                  final friend = controller.friends[index];
                  return InkWell(
                    onTap: () {
                      Get.to(() => ProfilePage(), arguments: friend.id);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 16),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundImage:
                            NetworkImage(friend.profilePictureUrl),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                friend.username,
                                style: Theme.of(context).textTheme.titleMedium,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                friend.isLawyer ? 'Lawyer' : 'Not a Lawyer',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      }),
    );
  }

  // ✅ 친구 목록이 없을 때의 UI
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/friend_placeholder.png', // ✅ 친구 없음 이미지 추가
            width: 200,
            height: 200,
          ),
          const SizedBox(height: 20),
          const Text(
            "아직 친구가 없습니다!",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            "친구를 추가하고 함께 법률 문제를 논의하세요.",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
          const SizedBox(height: 20),

          // ✅ Work Room 생성 버튼
          SizedBox(
            width: 200,
            child: ElevatedButton(
              onPressed: () {
                Get.to(() => FriendRequestPage()); // Work Room 생성 페이지 이동
              },
              child: const Text("내 첫 친구 추가하기"),
            ),
          ),
        ],
      ),
    );
  }
}
