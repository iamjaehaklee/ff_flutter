import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/friend/data/friend_request_repository.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FriendRequestController extends GetxController {
  final FriendRequestRepository repository = FriendRequestRepository(Supabase.instance.client);

  var isLoading = false.obs;
  var successMessage = ''.obs;
  var errorMessage = ''.obs;

  // ✅ 친구 요청 보내기 (로그 추가)
  Future<void> sendFriendRequest(String requesterId, String recipientEmail) async {
    try {
      print("🔄 [FriendRequestController] Sending friend request from '$requesterId' to '$recipientEmail'");

      isLoading(true);
      successMessage('');
      errorMessage('');

      final startTime = DateTime.now(); // ✅ 요청 시작 시간 로깅
      print("⏳ [FriendRequestController] Calling repository.sendFriendRequest...");

      final success = await repository.sendFriendRequest(requesterId, recipientEmail);

      final endTime = DateTime.now(); // ✅ 요청 종료 시간 로깅
      final duration = endTime.difference(startTime);
      print("✅ [FriendRequestController] API call completed in ${duration.inMilliseconds}ms");

      if (success) {
        successMessage('Friend request sent successfully.');
        print("📨 [FriendRequestController] Friend request successfully sent to $recipientEmail");
      } else {
        errorMessage('Failed to send friend request. User may not exist.');
        print("❌ [FriendRequestController] Friend request failed: User not found or another issue.");
      }
    } catch (e, stacktrace) {
      errorMessage('Error sending friend request.');
      print("❌ [FriendRequestController] Exception occurred while sending friend request: $e");
      print("🔍 [FriendRequestController] Stacktrace: $stacktrace");
    } finally {
      isLoading(false);
      print("🔄 [FriendRequestController] Finished processing friend request.");
    }
  }
}
