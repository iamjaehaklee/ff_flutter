import 'package:json_annotation/json_annotation.dart';

part 'friend_request_model.g.dart';

@JsonSerializable()
class FriendRequest {
  final String id;
  final String requesterId;
  final String recipientId;
  final String status;
  final DateTime sentAt;
  final DateTime? respondedAt;

  FriendRequest({
    required this.id,
    required this.requesterId,
    required this.recipientId,
    required this.status,
    required this.sentAt,
    this.respondedAt,
  });

  factory FriendRequest.fromJson(Map<String, dynamic> json) => _$FriendRequestFromJson(json);

  Map<String, dynamic> toJson() => _$FriendRequestToJson(this);
}
