import 'package:supabase_flutter/supabase_flutter.dart';

class FriendRequestRepository {
  final SupabaseClient supabase;

  FriendRequestRepository(this.supabase);

  // ✅ Supabase Edge Function `put_friend_request` 호출하여 친구 요청 또는 초대 이메일 발송
  Future<bool> sendFriendRequest(String requesterId, String recipientEmail) async {
    try {
      print("🔄 Sending friend request from '$requesterId' to '$recipientEmail'");

      final responseEdge = await supabase.functions.invoke(
        'put_friend_request',
        body: {
          'requester_id': requesterId,
          'recipient_email': recipientEmail,
        },
      );

      if (responseEdge.data == null) {
        print("❌ No data received from Edge Function.");
        return false;
      }

      print("✅ Friend request successfully sent via Edge Function.");
      return true;
    } catch (e, stacktrace) {
      print("❌ Error sending friend request: $e");
      print("🔍 Stacktrace: $stacktrace");
      return false;
    }
  }
}
