import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/painting.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image/image.dart' as img;
import 'document_annotation_model.dart';
import 'package:intl/intl.dart';

class AnnotationRepository {
  final SupabaseClient _supabase = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> fetchAnnotations(String parentFileStorageKey) async {
    try {
      print("Fetching annotations for parentFileStorageKey: $parentFileStorageKey...");

      // Call the Supabase RPC to fetch annotations
      final response = await _supabase.rpc(
        'get_document_annotations_by_parent_file_storage_key',
        params: {
          '_parent_file_storage_key': parentFileStorageKey,
        },
      );

      if (response is List) {
        print("Successfully fetched annotations for parentFileStorageKey: $parentFileStorageKey. Total annotations: ${response.length}");
        return List<Map<String, dynamic>>.from(response);
      } else {
        throw Exception("Unexpected response format for parentFileStorageKey: $parentFileStorageKey, response type: ${response.runtimeType}");
      }
    } catch (e) {
      print("Error fetching annotations for parentFileStorageKey: $parentFileStorageKey. Error: $e");
      throw Exception("Failed to fetch annotations: $e");
    }
  }

  Future<void> saveAnnotationToDatabase({
    required String workRoomId,
    required String fileName,
    required int page,
    required Rect rect,
    required String text,
    Uint8List? imageBytes,
  }) async {
    try {
      print("Starting saveAnnotationToDatabase...");

      // Convert Rect to x1, y1, x2, y2
      final rectJson = DocumentAnnotationModel.rectToJson(rect);

      // Generate storage keys
      DateTime now = DateTime.now().toUtc();
      String parentFileStorageKey = '$workRoomId/$fileName';
      print("Generated parentFileStorageKey: $parentFileStorageKey");

      String imageFileStorageKey = '$workRoomId/$fileName/page_${page}_${rectJson['x1']}_${rectJson['y1']}_${rectJson['x2']}_${rectJson['y2']}_${DateFormat('yyyyMMdd_HHmmss').format(now)}.png';
      print("Generated imageFileStorageKey: $imageFileStorageKey");

      // If there is an image, upload it to Supabase Storage
      String? publicUrl;
      if (imageBytes != null) {
        print("Uploading image to Supabase Storage for parentFileStorageKey: $parentFileStorageKey...");

        final uploadResponse = await _supabase.storage
            .from('work_room_annotations')
            .uploadBinary(imageFileStorageKey, imageBytes);

        if (uploadResponse == null || uploadResponse.isEmpty) {
          print("Image upload failed for parentFileStorageKey: $parentFileStorageKey.");
          throw Exception("Image upload failed.");
        }

        print("Image uploaded successfully for parentFileStorageKey: $parentFileStorageKey. Storage key: $imageFileStorageKey");

        // Get public URL of the uploaded image
        publicUrl = _supabase.storage
            .from('work_room_annotations')
            .getPublicUrl(imageFileStorageKey);

        print("Public URL for the image (parentFileStorageKey: $parentFileStorageKey): $publicUrl");
      } else {
        print("No imageBytes provided for parentFileStorageKey: $parentFileStorageKey, skipping image upload.");
      }

      if (publicUrl == null) {
        print("Public URL for the image is null for parentFileStorageKey: $parentFileStorageKey. Aborting annotation insertion.");
        return;
      }

      // Prepare annotation data
      Map<String, dynamic> annotationData = {
        'p_document_id': null,
        'p_parent_file_storage_key': parentFileStorageKey,
        'p_work_room_id': workRoomId,
        'p_page_number': page,
        'p_x1': rectJson['x1'],
        'p_y1': rectJson['y1'],
        'p_x2': rectJson['x2'],
        'p_y2': rectJson['y2'],
        'p_content': text,
        'p_annotation_type': 'manual',
        'p_image_file_storage_key': imageFileStorageKey,
        'p_is_ocr': false,
        'p_ocr_text': null,
        'p_created_by': '01ba12d0-da6a-45e0-8535-6d2e49a4f96e', // Replace with actual user ID
      };

      print("Prepared annotation data for parentFileStorageKey: $parentFileStorageKey. Data: ${json.encode(annotationData)}");

      // Save annotation data using RPC
      print("Saving annotation to database via RPC for parentFileStorageKey: $parentFileStorageKey...");
      final response = await _supabase.rpc('upsert_document_annotation', params: annotationData);

      if (response && response.error != null) {
        print("Failed to insert annotation for parentFileStorageKey: $parentFileStorageKey. Error: ${response.error.message}");
        throw Exception("Failed to insert annotation: ${response.error.message}");
      }

      print("Annotation saved successfully for parentFileStorageKey: $parentFileStorageKey.");
    } catch (e, stackTrace) {
      print("Stack trace: $stackTrace");
      rethrow;
    } finally {
      print("saveAnnotationToDatabase process completed .");
    }
  }
  Future<String> getPublicUrl(String imageStorageKey) async {
    try {
      final publicUrl = _supabase.storage
          .from('work_room_annotations')
          .getPublicUrl(imageStorageKey);

      print("Public URL for $imageStorageKey: $publicUrl");
      return publicUrl;
    } catch (e) {
      print("Failed to get public URL for $imageStorageKey: $e");
      throw Exception("Failed to get public URL for $imageStorageKey.");
    }
  }
}
