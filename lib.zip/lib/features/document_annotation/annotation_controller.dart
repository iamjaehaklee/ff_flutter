import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/document_annotation/data/annotation_repository.dart';

class AnnotationController extends GetxController {
  final AnnotationRepository _annotationRepository = AnnotationRepository();

  RxList<Map<String, dynamic>> annotations = RxList<Map<String, dynamic>>([]);
  RxBool isLoading = false.obs;
  RxString errorMessage = ''.obs;

  Future<void> fetchAnnotations(String parentFileStorageKey) async {
    try {
      isLoading.value = true;
      // Call the repository to fetch data
      final fetchedAnnotations =
      await _annotationRepository.fetchAnnotations(parentFileStorageKey);

      annotations.value = fetchedAnnotations;
    } catch (e) {
      errorMessage.value = "Failed to fetch annotations: $e";
    } finally {
      isLoading.value = false;
    }
  }
}
