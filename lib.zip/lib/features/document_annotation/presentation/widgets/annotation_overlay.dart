import 'package:flutter/material.dart';

class AnnotationOverlay extends StatelessWidget {
  final List<Map<String, dynamic>> annotations;
  final Function(Rect rect) onAddAnnotation;

  const AnnotationOverlay({
    Key? key,
    required this.annotations,
    required this.onAddAnnotation,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (details) {
        final startOffset = details.localPosition;
        onAddAnnotation(Rect.fromPoints(startOffset, startOffset));
      },
      onPanUpdate: (details) {
        final endOffset = details.localPosition;
        onAddAnnotation(Rect.fromPoints(annotations.last['startOffset'], endOffset));
      },
      child: Stack(
        children: [
          // Draw existing annotations
          ...annotations.map((annotation) {
            return Positioned.fromRect(
              rect: annotation['rect'],
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blue, width: 2),
                  color: Colors.blue.withOpacity(0.1),
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
