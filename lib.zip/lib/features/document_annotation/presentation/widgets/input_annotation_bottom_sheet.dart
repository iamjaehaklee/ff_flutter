// File: lib/widgets/input_annotation_bottom_sheet.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/document_annotation/annotation_controller.dart';

class InputAnnotationBottomSheet extends StatelessWidget {
  final Function(String) onSave;
  final Uint8List? image;
  // 추가 매개변수: DB 저장을 위해 필요한 정보들
  final String workRoomId;
  final String fileName;
  final int page;
  final Rect selectionRect;

  const InputAnnotationBottomSheet({
    Key? key,
    required this.onSave,
    this.image,
    required this.workRoomId,
    required this.fileName,
    required this.page,
    required this.selectionRect,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String annotationText = "";

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        top: 16,
        left: 24,
        right: 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 16),
          if (image != null) Image.memory(image!, height: 150),
          const SizedBox(height: 16),
          TextField(
            decoration: const InputDecoration(
              labelText: "Enter annotation",
              border: OutlineInputBorder(),
            ),
            minLines: 3,
            maxLines: 8,
            onChanged: (value) => annotationText = value,
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(
                width: 150,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
              ),
              const SizedBox(width: 30),
              SizedBox(
                width: 150,
                child: ElevatedButton(
                  onPressed: () async {
                    if (annotationText.isNotEmpty) {
                      // DB에 어노테이션 저장하는 로직 추가
                      final AnnotationController controller = Get.find<AnnotationController>();
                      bool success = await controller.saveAnnotation(
                        workRoomId: workRoomId,
                        fileName: fileName,
                        page: page,
                        rect: selectionRect,
                        text: annotationText,
                        imageBytes: image,
                      );
                      if (success) {
                        onSave(annotationText);
                        Navigator.pop(context);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Failed to save annotation.")),
                        );
                      }
                    }
                  },
                  child: const Text("Save comment"),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
