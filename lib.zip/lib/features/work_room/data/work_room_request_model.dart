import 'package:json_annotation/json_annotation.dart';

part 'work_room_request_model.g.dart';

@JsonSerializable()
class WorkRoomRequest {
  final String id;
  final String requesterId;
  final String recipientId;
  final String workRoomId;
  final String status;
  final DateTime sentAt;
  final DateTime? respondedAt;

  WorkRoomRequest({
    required this.id,
    required this.requesterId,
    required this.recipientId,
    required this.workRoomId,
    required this.status,
    required this.sentAt,
    this.respondedAt,
  });

  factory WorkRoomRequest.fromJson(Map<String, dynamic> json) => _$WorkRoomRequestFromJson(json);

  Map<String, dynamic> toJson() => _$WorkRoomRequestToJson(this);
}
//flutter pub run build_runner build