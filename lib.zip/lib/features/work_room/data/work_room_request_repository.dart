import 'package:supabase_flutter/supabase_flutter.dart';

class WorkRoomRequestRepository {
  final SupabaseClient supabase;

  WorkRoomRequestRepository(this.supabase);

  // ✅ Supabase Edge Function `put_work_room_request` 호출하여 WorkRoom 요청 처리
  Future<bool> sendWorkRoomRequest(String requesterId, String recipientEmail, String workRoomId) async {
    try {
      print("🔄 [WorkRoomRequestRepository] Sending WorkRoom request from '$requesterId' to '$recipientEmail' for WorkRoom '$workRoomId'");

      final startTime = DateTime.now();
      print("⏳ [WorkRoomRequestRepository] Invoking Supabase Edge Function...");

      final responseEdge = await supabase.functions.invoke(
        'put_work_room_request',
        body: {
          'requester_id': requesterId,
          'recipient_email': recipientEmail,
          'work_room_id': workRoomId,
        },
      );

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime);
      print("✅ [WorkRoomRequestRepository] Edge Function completed in ${duration.inMilliseconds}ms");

      if (responseEdge.data == null) {
        print("❌ [WorkRoomRequestRepository] No data received from Edge Function.");
        return false;
      }

      print("✅ [WorkRoomRequestRepository] WorkRoom request successfully sent via Edge Function.");
      return true;
    } catch (e, stacktrace) {
      print("❌ [WorkRoomRequestRepository] Error sending WorkRoom request: $e");
      print("🔍 [WorkRoomRequestRepository] Stacktrace: $stacktrace");
      return false;
    }
  }
}
