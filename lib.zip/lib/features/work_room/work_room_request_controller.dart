import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/work_room/data/work_room_request_repository.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class WorkRoomRequestController extends GetxController {
  final WorkRoomRequestRepository repository = WorkRoomRequestRepository(Supabase.instance.client);

  var isLoading = false.obs;
  var successMessage = ''.obs;
  var errorMessage = ''.obs;

  // ✅ WorkRoom 초대 요청 보내기
  Future<void> sendWorkRoomRequest(String requesterId, String recipientEmail, String workRoomId) async {
    try {
      final startTime = DateTime.now();
      print("🔄 [WorkRoomRequestController] Sending WorkRoom request from '$requesterId' to '$recipientEmail' for WorkRoom '$workRoomId' at $startTime");

      isLoading(true);
      successMessage('');
      errorMessage('');

      print("⏳ [WorkRoomRequestController] Calling repository.sendWorkRoomRequest...");
      final success = await repository.sendWorkRoomRequest(requesterId, recipientEmail, workRoomId);

      final endTime = DateTime.now();
      final duration = endTime.difference(startTime);
      print("✅ [WorkRoomRequestController] API call completed in ${duration.inMilliseconds}ms");

      if (success) {
        successMessage('WorkRoom request sent successfully.');
        print("📨 [WorkRoomRequestController] WorkRoom request successfully sent to $recipientEmail");
      } else {
        errorMessage('Failed to send WorkRoom request. User may not exist.');
        print("❌ [WorkRoomRequestController] WorkRoom request failed: User not found or another issue.");
      }
    } catch (e, stacktrace) {
      errorMessage('Error sending WorkRoom request.');
      print("❌ [WorkRoomRequestController] Exception occurred while sending WorkRoom request: $e");
      print("🔍 [WorkRoomRequestController] Stacktrace: $stacktrace");
    } finally {
      isLoading(false);
      print("🔄 [WorkRoomRequestController] Finished processing WorkRoom request.");
    }
  }
}
