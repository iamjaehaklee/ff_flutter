import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/document_annotation/data/annotation_repository.dart';
import 'package:legalfactfinder2025/features/files/file_view_controller.dart';
import 'package:legalfactfinder2025/features/files/presentation/widgets/page_controller_widget.dart';
import 'package:pdf_render/pdf_render.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:image/image.dart' as img; // For cropping image pixels
import 'package:path_provider/path_provider.dart';

class PDFFileViewScreen extends StatefulWidget {
  final String workRoomId;
  final String fileName;

  const PDFFileViewScreen({
    Key? key,
    required this.workRoomId,
    required this.fileName,
  }) : super(key: key);

  @override
  _PDFFileViewScreenState createState() => _PDFFileViewScreenState();
}

class _PDFFileViewScreenState extends State<PDFFileViewScreen> with AutomaticKeepAliveClientMixin {
  final GlobalKey _pdfViewKey = GlobalKey(); // GlobalKey 추가


  @override
  bool get wantKeepAlive => true;

  PDFViewController? _pdfViewController;
  int _currentPage = 0;
  int _totalPages = 0;

  bool _isAnnotationMode = false;
  Rect? _selectedRect;
  ui.Image? _croppedImage;

  final AnnotationRepository _annotationRepository = AnnotationRepository();

  @override
  void initState() {
    super.initState();
    final FileViewController controller = Get.find<FileViewController>();
    controller.loadFile(
      'work_room_files',
      '${widget.workRoomId}/${widget.fileName}',
      widget.fileName,
    );
  }



  void _startDrawing(Offset startPosition) {
    setState(() {
      _selectedRect = Rect.fromLTWH(startPosition.dx, startPosition.dy, 0, 0);
    });
  }

  void _updateDrawing(Offset currentPosition) {
    setState(() {
      if (_selectedRect != null) {
        _selectedRect = Rect.fromLTRB(
          _selectedRect!.left < currentPosition.dx ? _selectedRect!.left : currentPosition.dx,
          _selectedRect!.top < currentPosition.dy ? _selectedRect!.top : currentPosition.dy,
          _selectedRect!.right > currentPosition.dx ? _selectedRect!.right : currentPosition.dx,
          _selectedRect!.bottom > currentPosition.dy ? _selectedRect!.bottom : currentPosition.dy,
        );
      }
    });
  }

  void _updateCorner(Offset delta, Alignment alignment) {
    setState(() {
      if (_selectedRect == null) return;

      double left = _selectedRect!.left;
      double top = _selectedRect!.top;
      double right = _selectedRect!.right;
      double bottom = _selectedRect!.bottom;

      if (alignment == Alignment.topLeft) {
        left += delta.dx;
        top += delta.dy;
      } else if (alignment == Alignment.topRight) {
        right += delta.dx;
        top += delta.dy;
      } else if (alignment == Alignment.bottomLeft) {
        left += delta.dx;
        bottom += delta.dy;
      } else if (alignment == Alignment.bottomRight) {
        right += delta.dx;
        bottom += delta.dy;
      }

      _selectedRect = Rect.fromLTRB(
        left < right ? left : right,
        top < bottom ? top : bottom,
        left < right ? right : left,
        top < bottom ? bottom : top,
      );
    });
  }

  Future<void> _showBottomSheet(BuildContext context) async {
    String annotationText = "";

    // Capture the selected area
    await _captureSelectedArea();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            top: 16,
            left: 16,
            right: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Display the cropped image
              if (_croppedImage != null)
                Container(
                  width: double.infinity,
                  // height: 200,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black12),
                  ),
                  child: RawImage(image: _croppedImage),
                ),
              const SizedBox(height: 16),
              // TextField for annotation input
              TextField(
                decoration: const InputDecoration(

                  labelText: "Enter annotation",
                  border: OutlineInputBorder(),

                ),
                minLines: 3,
                maxLines: 8,
                onChanged: (value) {
                  annotationText = value;
                },
              ),
              const SizedBox(height: 16),
              // Save button
              ElevatedButton(
                onPressed: () async {
                  if (annotationText.isNotEmpty && _selectedRect != null) {


                    ByteData? byteData = await _croppedImage?.toByteData(format: ui.ImageByteFormat.png); // ByteData로 변환
                    Uint8List? uint8List = byteData?.buffer.asUint8List(); // Uint8List로 변환

                    await _annotationRepository.saveAnnotationToDatabase(
                      workRoomId: widget.workRoomId,
                      fileName: widget.fileName,
                      page: _currentPage,
                      rect: _selectedRect!,
                      text: annotationText,
                      imageBytes: uint8List
                    );
                    Navigator.pop(context); // Close the bottom sheet
                    setState(() {
                      _selectedRect = null;
                      _croppedImage = null; // Reset the cropped image
                    });
                  }
                },
                child: const Text("Save"),
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCornerMarker(Alignment alignment) {
    return Positioned(
      left: alignment == Alignment.topLeft || alignment == Alignment.bottomLeft
          ? _selectedRect!.left - 6
          : _selectedRect!.right - 6,
      top: alignment == Alignment.topLeft || alignment == Alignment.topRight
          ? _selectedRect!.top - 6
          : _selectedRect!.bottom - 6,
      child: GestureDetector(
        onPanUpdate: (details) => _updateCorner(details.delta, alignment),
        child: Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.red, width: 2),
            shape: BoxShape.circle, // 꼭지점을 동그랗게 표시
          ),
        ),
      ),
    );
  }

  Future<String> copyPdfToAppDirectory(String filePath) async {
    final appDir = await getApplicationDocumentsDirectory();
    final newFilePath = '${appDir.path}/temp.pdf';
    final file = File(filePath);
    await file.copy(newFilePath);
    return newFilePath;
  }

  Future<void> _captureSelectedArea() async {
    final FileViewController controller = Get.find<FileViewController>();

    if (_pdfViewController == null || _selectedRect == null) return;

    final file = controller.file.value;
    if (file == null) {
      print('File not loaded or does not exist.');
      return;
    }

    print('Using file path from FileViewController: ${file.path}');

    // Open PDF document
    final doc = await PdfDocument.openFile(file.path);
    final page = await doc.getPage(_currentPage + 1);

    // Render the page as an image
    final renderedPage = await page.render(
      width: page.width.toInt(),
      height: page.height.toInt(),
      fullWidth: page.width,
      fullHeight: page.height,
    );

    final imageBytes = renderedPage.pixels;
    final image = img.Image.fromBytes(
      width: renderedPage.width,
      height: renderedPage.height,
      bytes: imageBytes.buffer,
    );

    // Get PDFView size from the GlobalKey
    final RenderBox pdfViewBox = _pdfViewKey.currentContext!.findRenderObject() as RenderBox;
    final double pdfViewWidth = pdfViewBox.size.width;
    final double pdfViewHeight = pdfViewBox.size.height;

    // Calculate scale factors
    final double scaleX = renderedPage.width / pdfViewWidth;
    final double scaleY = renderedPage.height / pdfViewHeight;

    // Adjust Y coordinate to match PDF's coordinate system
    final cropLeft = (_selectedRect!.left * scaleX).toInt();
    final cropTop = ((_selectedRect!.top * scaleY)).toInt();
    final cropWidth = (_selectedRect!.width * scaleX).toInt();
    final cropHeight = (_selectedRect!.height * scaleY).toInt();

    // Crop the selected area from the rendered image
    final croppedImage = img.copyCrop(
      image,
      x:cropLeft,
      y:cropTop,
      width:cropWidth,
height:      cropHeight,
    );

    // Convert the cropped image to ui.Image for display
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final paint = Paint();
    final uiImage = await _convertToUiImage(croppedImage);

    canvas.drawImage(uiImage, Offset.zero, paint);
    final picture = recorder.endRecording();
    final croppedUiImage = await picture.toImage(cropWidth, cropHeight);

    setState(() {
      _croppedImage = croppedUiImage;
    });
  }



  Future<ui.Image> _convertToUiImage(img.Image image) async {
    final completer = Completer<ui.Image>();
    final byteData = Uint8List.fromList(img.encodePng(image));
    ui.decodeImageFromList(byteData, (ui.Image img) {
      completer.complete(img);
    });
    return completer.future;
  }


  @override
  Widget build(BuildContext context) {
    super.build(context);

    final FileViewController controller = Get.find<FileViewController>();

    return Obx(() {
      if (controller.isLoading.value) {
        return const Center(child: CircularProgressIndicator());
      }

      if (controller.errorMessage.isNotEmpty) {
        return Center(child: Text(controller.errorMessage.value));
      }

      if (controller.file.value == null) {
        return const Center(child: Text("File not found."));
      }

      final file = controller.file.value!;
      final fileType = widget.fileName.split('.').last.toLowerCase();

      if (fileType == 'pdf') {
        return Stack(
          children: [
            GestureDetector(
              onPanStart: _isAnnotationMode
                  ? (details) {
                _startDrawing(details.localPosition);
              }
                  : null,
              onPanUpdate: _isAnnotationMode
                  ? (details) {
                _updateDrawing(details.localPosition);
              }
                  : null,
              child: PDFView(
                key: _pdfViewKey, // GlobalKey 할당

                filePath: file.path,
                onRender: (pages) {
                  setState(() {
                    _totalPages = pages ?? 0;
                  });
                },
                onPageChanged: (page, total) {
                  setState(() {
                    _currentPage = page ?? 0;
                  });
                },
                onViewCreated: (PDFViewController pdfViewController) {
                  setState(() {
                    _pdfViewController = pdfViewController;
                  });
                },
              ),
            ),
            if (_selectedRect != null)
              Positioned.fromRect(
                rect: _selectedRect!,
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.red, width: 2),
                    color: Colors.red.withOpacity(0.2),
                  ),
                ),
              ),
            if (_selectedRect != null) ...[
              _buildCornerMarker(Alignment.topLeft),
              _buildCornerMarker(Alignment.topRight),
              _buildCornerMarker(Alignment.bottomLeft),
              _buildCornerMarker(Alignment.bottomRight),
            ],
            if (_pdfViewController != null)
              Positioned(
                bottom: 0, // 화면의 맨 아\래로 위치
                left: 0,
                right: 0,
                child: Container(
                  height: MediaQuery.of(context).size.height / 10, // 높이 축소
                  color: Colors.black.withOpacity(0.7), // 배경색 추가
                  child: PageControllerWidget(
                    currentPage: _currentPage,
                    totalPages: _totalPages,
                    pdfViewController: _pdfViewController!,
                    arrowSize: 20, // 화살표 크기를 약간 줄임
                  ),
                ),
              ),
            Positioned(
              bottom: 80,
              right: 16,
              child: _isAnnotationMode
                  ? Column(
                children: [
                  FloatingActionButton(
                    mini: true,
                    heroTag: "Cancel",
                    backgroundColor: Colors.red,
                    onPressed: () {
                      setState(() {
                        _isAnnotationMode = false;
                        _selectedRect = null;
                      });
                    },
                    child: const Icon(Icons.close, color: Colors.white),
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    mini: true,
                    heroTag: "Save",
                    backgroundColor: Colors.blue,
                    onPressed: () async {
                      if (_selectedRect != null) {
                        await _showBottomSheet(context);
                      }
                    },
                    child: const Icon(Icons.check, color: Colors.white),
                  ),
                ],
              )
                  : FloatingActionButton(
                mini: true,
                onPressed: () {
                  setState(() {
                    _isAnnotationMode = true;
                    _selectedRect = null;
                  });
                },
                backgroundColor: Colors.blue,
                child: const Icon(Icons.comment, color: Colors.white),
              ),
            ),
          ],
        );
      } else {
        return const Center(child: Text("Unsupported file type."));
      }
    });
  }
}
