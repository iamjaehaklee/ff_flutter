// File: lib/screens/file_annotation_threads_screen.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:legalfactfinder2025/features/document_annotation/annotation_controller.dart';
import 'package:legalfactfinder2025/features/document_annotation/data/annotation_repository.dart';
import 'package:legalfactfinder2025/features/document_annotation/data/document_annotation_model.dart';
import 'package:legalfactfinder2025/features/document_annotation/presentation/annotation_thread_screen.dart';

class FileAnnotationThreadsScreen extends StatefulWidget {
  final String workRoomId;
  final String fileName;
  final String parentFileStorageKey;

  const FileAnnotationThreadsScreen({
    Key? key,
    required this.workRoomId,
    required this.fileName,
    required this.parentFileStorageKey,
  }) : super(key: key);

  @override
  _FileAnnotationThreadsScreenState createState() =>
      _FileAnnotationThreadsScreenState();
}

class _FileAnnotationThreadsScreenState
    extends State<FileAnnotationThreadsScreen> with AutomaticKeepAliveClientMixin {
  final AnnotationController controller = Get.put(AnnotationController());
  final AnnotationRepository repository = AnnotationRepository();

  @override
  void initState() {
    super.initState();
    // 상세 파라미터 로그
    debugPrint('[FileAnnotationThreadsScreen.initState] workRoomId: ${widget.workRoomId}');
    debugPrint('[FileAnnotationThreadsScreen.initState] fileName: ${widget.fileName}');
    debugPrint('[FileAnnotationThreadsScreen.initState] parentFileStorageKey: ${widget.parentFileStorageKey}');
    controller.fetchAnnotations(widget.parentFileStorageKey);
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin

    return Obx(() {
      if (controller.isLoading.value) {
        debugPrint('[FileAnnotationThreadsScreen.build] isLoading true');
        return const Center(child: CircularProgressIndicator());
      }

      if (controller.errorMessage.isNotEmpty) {
        debugPrint('[FileAnnotationThreadsScreen.build] errorMessage: ${controller.errorMessage.value}');
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(controller.errorMessage.value, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  debugPrint('[FileAnnotationThreadsScreen.build] Retry button pressed. Fetching annotations for parentFileStorageKey: ${widget.parentFileStorageKey}');
                  controller.fetchAnnotations(widget.parentFileStorageKey);
                },
                child: const Text("Retry"),
              ),
            ],
          ),
        );
      }

      if (controller.annotations.isEmpty) {
        debugPrint('[FileAnnotationThreadsScreen.build] No annotations found.');
        return const Center(child: Text("No annotations found."));
      }

      return ListView.separated(
        itemCount: controller.annotations.length,
        separatorBuilder: (context, index) => const Divider(height: 40),
        itemBuilder: (context, index) {
          final annotation = DocumentAnnotationModel.fromJson(controller.annotations[index]);
          debugPrint('[FileAnnotationThreadsScreen.itemBuilder] Annotation ${index + 1}: ${jsonEncode(annotation.toJson())}');
          return GestureDetector(
            onTap: () {
              debugPrint('[FileAnnotationThreadsScreen.onTap] Tapped annotation ${index + 1}');
              _showAnnotationThreadBottomSheet(context, annotation.toJson());
            },
            child: Container(
              margin: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (annotation.imageFileStorageKey != null)
                    FutureBuilder<String>(
                      future: repository.getPublicUrl(annotation.imageFileStorageKey!),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        }
                        if (snapshot.hasError) {
                          return Text(
                            "Error loading image: ${snapshot.error}",
                            style: const TextStyle(color: Colors.red),
                          );
                        }
                        if (snapshot.hasData) {
                          return Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                            child: Image.network(
                              snapshot.data!,
                              fit: BoxFit.contain,
                              width: double.infinity,
                            ),
                          );
                        }
                        return const Text("No image available.");
                      },
                    ),
                  ListTile(
                    leading: annotation.createdBy != null
                        ? CircleAvatar(
                      backgroundImage: NetworkImage(annotation.createdBy!),
                    )
                        : const CircleAvatar(
                      child: Icon(Icons.person),
                    ),
                    title: Text(annotation.createdBy ?? 'Unknown User'),
                    subtitle: Text(annotation.content ?? 'No Content'),
                  ),
                ],
              ),
            ),
          );
        },
      );
    });
  }

  /// Show the Bottom Sheet with annotation threads
  void _showAnnotationThreadBottomSheet(BuildContext context, Map<String, dynamic> annotationData) {
    debugPrint('[FileAnnotationThreadsScreen._showAnnotationThreadBottomSheet] Received annotationData: ${jsonEncode(annotationData)}');
    final annotation = DocumentAnnotationModel.fromJson(annotationData); // Convert map to model
    debugPrint('[FileAnnotationThreadsScreen._showAnnotationThreadBottomSheet] Parsed annotation: ${annotation.toJson()}');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.9, // 90% of the screen
          maxChildSize: 0.9,
          minChildSize: 0.4,
          expand: false,
          builder: (context, scrollController) {
            debugPrint('[FileAnnotationThreadsScreen._showAnnotationThreadBottomSheet] Opening AnnotationThreadScreen with annotation: ${annotation.toJson()}');
            return AnnotationThreadScreen(
              annotation: annotation,
              scrollController: scrollController,
            );
          },
        );
      },
    );
  }
}
