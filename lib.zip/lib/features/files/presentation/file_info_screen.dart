import 'package:flutter/material.dart';

class FileInfoScreen extends StatefulWidget {
  const FileInfoScreen({super.key});

  @override
  State<FileInfoScreen> createState() => _FileInfoScreenState();
}

class _FileInfoScreenState extends State<FileInfoScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
