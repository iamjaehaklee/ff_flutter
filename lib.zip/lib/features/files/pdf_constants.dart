// File: lib/pdf_constants.dart
import 'package:flutter/material.dart';

const double kPdfRenderScale = 3.0;
const Color kPdfBackgroundColor = Colors.white;
const double kAnnotationOverlayOpacity = 0.5;

// End of pdf_constants.dart
